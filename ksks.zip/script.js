function kalkulatorCinta() {
    const nama1 = document.getElementById("nama1").value.trim();
    const nama2 = document.getElementById("nama2").value.trim();
    const forbiddenNames = ["musa", "marselino", "lino", "selin","marsel"];

    // Convert names to lowercase to check for forbidden names
    if (forbiddenNames.includes(nama1.toLowerCase()) || forbiddenNames.includes(nama2.toLowerCase())) {
        document.getElementById("result").innerText = "Ngapain pake nama gw?";
        document.getElementById("fortune").innerText = ""; // Clear any previous fortune
        document.getElementById("heart").style.opacity = '0'; // Hide heart if any
        return;
    }

    const kombinasiNama = (nama1 + nama2).toLowerCase();
    let sum = 0;

    for (let char of kombinasiNama) {
        sum += char.charCodeAt(0);
    }

    const randomSeed = sum % 101;
    const persentaseCinta = Math.floor(Math.random() * randomSeed);

    document.getElementById("result").innerText = `Hasil cinta antara ${nama1} dan ${nama2} adalah: ${persentaseCinta}%`;

    // Show heart animation
    const heart = document.getElementById("heart");
    heart.style.opacity = '1';
    heart.style.animation = 'fadeInScale 1s ease-out forwards';

    // Display fortune based on percentage
    let fortune = "";
    if (persentaseCinta >= 80) {
        fortune = "Kalian adalah pasangan yang sempurna! Cinta sejati di depan mata.";
    } else if (persentaseCinta >= 60) {
        fortune = "Ada potensi besar di antara kalian, lanjutkan dan lihat ke mana arah hubungan ini.";
    } else if (persentaseCinta >= 40) {
        fortune = "Tidak buruk, tapi mungkin kalian butuh lebih banyak waktu untuk lebih dekat.";
    } else if (persentaseCinta >= 20) {
        fortune = "Ada sedikit ketertarikan, tapi mungkin kalian lebih cocok sebagai teman.";
    } else {
        fortune = "Sepertinya kalian ditakdirkan untuk jadi teman baik, bukan kekasih.";
    }

    const fortuneElement = document.getElementById("fortune");
    fortuneElement.innerText = fortune;
}
